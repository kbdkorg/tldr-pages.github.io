# gjoin

> Det här kommandot är ett alias för `-p linux join`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux join`
