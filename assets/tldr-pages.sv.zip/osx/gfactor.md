# gfactor

> Det här kommandot är ett alias för `-p linux factor`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux factor`
