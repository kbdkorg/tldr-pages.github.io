# gfold

> Det här kommandot är ett alias för `-p linux fold`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux fold`
