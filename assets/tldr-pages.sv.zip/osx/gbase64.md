# gbase64

> Det här kommandot är ett alias för `-p linux base64`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux base64`
