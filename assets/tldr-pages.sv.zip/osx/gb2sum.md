# gb2sum

> Det här kommandot är ett alias för `-p linux b2sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux b2sum`
