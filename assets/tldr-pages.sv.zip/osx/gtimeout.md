# gtimeout

> Det här kommandot är ett alias för `-p linux timeout`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux timeout`
