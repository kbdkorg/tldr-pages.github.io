# gsha256sum

> Det här kommandot är ett alias för `-p linux sha256sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sha256sum`
