# ged

> Det här kommandot är ett alias för `-p linux ed`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ed`
