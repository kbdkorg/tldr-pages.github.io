# gegrep

> Det här kommandot är ett alias för `-p linux egrep`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux egrep`
