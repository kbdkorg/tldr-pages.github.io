# gcomm

> Det här kommandot är ett alias för `-p linux comm`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux comm`
