# gtr

> Det här kommandot är ett alias för `-p linux tr`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux tr`
