# guptime

> Det här kommandot är ett alias för `-p linux uptime`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux uptime`
