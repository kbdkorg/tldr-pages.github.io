# gpaste

> Det här kommandot är ett alias för `-p linux paste`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux paste`
