# ggroups

> Det här kommandot är ett alias för `-p linux groups`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux groups`
