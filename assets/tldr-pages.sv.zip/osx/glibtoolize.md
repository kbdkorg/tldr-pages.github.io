# glibtoolize

> Det här kommandot är ett alias för `-p linux libtoolize`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux libtoolize`
