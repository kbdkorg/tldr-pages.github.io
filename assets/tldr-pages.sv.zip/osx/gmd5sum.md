# gmd5sum

> Det här kommandot är ett alias för `-p linux md5sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux md5sum`
