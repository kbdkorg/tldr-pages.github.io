# gbasenc

> Det här kommandot är ett alias för `-p linux basenc`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux basenc`
