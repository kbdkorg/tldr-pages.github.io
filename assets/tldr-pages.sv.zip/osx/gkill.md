# gkill

> Det här kommandot är ett alias för `-p linux kill`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux kill`
