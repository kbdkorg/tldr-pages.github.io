# gtsort

> Det här kommandot är ett alias för `-p linux tsort`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux tsort`
