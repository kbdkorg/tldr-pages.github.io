# gnice

> Det här kommandot är ett alias för `-p linux nice`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux nice`
