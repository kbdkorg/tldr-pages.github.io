# gmknod

> Det här kommandot är ett alias för `-p linux mknod`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux mknod`
