# gtrue

> Det här kommandot är ett alias för `-p linux true`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux true`
