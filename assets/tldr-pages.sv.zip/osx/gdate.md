# gdate

> Det här kommandot är ett alias för `-p linux date`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux date`
