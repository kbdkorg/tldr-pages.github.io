# gpwd

> Det här kommandot är ett alias för `-p linux pwd`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux pwd`
