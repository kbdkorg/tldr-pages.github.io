# grealpath

> Det här kommandot är ett alias för `-p linux realpath`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux realpath`
