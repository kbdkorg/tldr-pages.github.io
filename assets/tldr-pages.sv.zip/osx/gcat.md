# gcat

> Det här kommandot är ett alias för `-p linux cat`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux cat`
