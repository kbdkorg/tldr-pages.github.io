# gsha384sum

> Det här kommandot är ett alias för `-p linux sha384sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sha384sum`
