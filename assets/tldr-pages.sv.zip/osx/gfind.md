# gfind

> Det här kommandot är ett alias för `-p linux find`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux find`
