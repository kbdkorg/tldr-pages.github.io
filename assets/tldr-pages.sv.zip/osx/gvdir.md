# gvdir

> Det här kommandot är ett alias för `-p linux vdir`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux vdir`
