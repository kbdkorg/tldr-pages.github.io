# gwhoami

> Det här kommandot är ett alias för `-p linux whoami`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux whoami`
