# gmake

> Det här kommandot är ett alias för `-p linux make`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux make`
