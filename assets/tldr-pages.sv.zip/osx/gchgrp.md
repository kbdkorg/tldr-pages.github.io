# gchgrp

> Det här kommandot är ett alias för `-p linux chgrp`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux chgrp`
