# gbase32

> Det här kommandot är ett alias för `-p linux base32`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux base32`
