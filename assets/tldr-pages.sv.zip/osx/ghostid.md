# ghostid

> Det här kommandot är ett alias för `-p linux hostid`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux hostid`
