# gdd

> Det här kommandot är ett alias för `-p linux dd`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux dd`
