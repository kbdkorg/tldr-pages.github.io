# gmkdir

> Det här kommandot är ett alias för `-p linux mkdir`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux mkdir`
