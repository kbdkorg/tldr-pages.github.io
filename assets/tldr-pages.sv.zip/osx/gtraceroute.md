# gtraceroute

> Det här kommandot är ett alias för `-p linux traceroute`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux traceroute`
