# gdir

> Det här kommandot är ett alias för `-p linux dir`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux dir`
