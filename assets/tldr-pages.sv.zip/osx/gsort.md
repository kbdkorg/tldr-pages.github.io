# gsort

> Det här kommandot är ett alias för `-p linux sort`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sort`
