# gtac

> Det här kommandot är ett alias för `-p linux tac`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux tac`
