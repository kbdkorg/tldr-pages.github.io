# gstty

> Det här kommandot är ett alias för `-p linux stty`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux stty`
