# gsum

> Det här kommandot är ett alias för `-p linux sum`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux sum`
