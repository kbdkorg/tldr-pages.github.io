# gdnsdomainname

> Det här kommandot är ett alias för `-p linux dnsdomainname`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux dnsdomainname`
