# gcut

> Det här kommandot är ett alias för `-p linux cut`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux cut`
