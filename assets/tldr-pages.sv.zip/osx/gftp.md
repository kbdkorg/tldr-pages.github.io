# gftp

> Det här kommandot är ett alias för `-p linux ftp`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ftp`
