# gtruncate

> Det här kommandot är ett alias för `-p linux truncate`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux truncate`
