# god

> Det här kommandot är ett alias för `-p linux od`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux od`
