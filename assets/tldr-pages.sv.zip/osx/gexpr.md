# gexpr

> Det här kommandot är ett alias för `-p linux expr`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux expr`
