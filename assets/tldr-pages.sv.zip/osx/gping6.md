# gping6

> Det här kommandot är ett alias för `-p linux ping6`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ping6`
