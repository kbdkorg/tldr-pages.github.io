# gping

> Det här kommandot är ett alias för `-p linux ping`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux ping`
