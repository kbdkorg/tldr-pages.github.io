# gwc

> Det här kommandot är ett alias för `-p linux wc`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux wc`
