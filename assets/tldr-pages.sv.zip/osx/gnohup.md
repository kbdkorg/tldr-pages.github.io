# gnohup

> Det här kommandot är ett alias för `-p linux nohup`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux nohup`
