# gpinky

> Det här kommandot är ett alias för `-p linux pinky`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux pinky`
