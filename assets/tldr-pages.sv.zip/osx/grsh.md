# grsh

> Det här kommandot är ett alias för `-p linux rsh`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux rsh`
