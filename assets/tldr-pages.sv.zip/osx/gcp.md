# gcp

> Det här kommandot är ett alias för `-p linux cp`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux cp`
