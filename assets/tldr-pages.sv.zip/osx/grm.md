# grm

> Det här kommandot är ett alias för `-p linux rm`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux rm`
