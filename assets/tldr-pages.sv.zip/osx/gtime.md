# gtime

> Det här kommandot är ett alias för `-p linux time`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux time`
