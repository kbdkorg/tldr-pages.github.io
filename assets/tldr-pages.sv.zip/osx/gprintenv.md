# gprintenv

> Det här kommandot är ett alias för `-p linux printenv`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux printenv`
