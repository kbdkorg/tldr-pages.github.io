# aa

> Det här kommandot är ett alias för `yaa`.

- Se dokumentationen för orginalkommandot:

`tldr yaa`
