# gusers

> Det här kommandot är ett alias för `-p linux users`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux users`
