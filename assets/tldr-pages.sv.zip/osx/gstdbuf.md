# gstdbuf

> Det här kommandot är ett alias för `-p linux stdbuf`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux stdbuf`
