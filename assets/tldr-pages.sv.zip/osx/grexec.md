# grexec

> Det här kommandot är ett alias för `-p linux rexec`.

- Se dokumentationen för orginalkommandot:

`tldr -p linux rexec`
