# ncal

> Det här kommandot är ett alias för `cal`.
> Mer information: <https://manned.org/ncal>.

- Se dokumentationen för orginalkommandot:

`tldr cal`
