# alternatives

> Det här kommandot är ett alias för `update-alternatives`.
> Mer information: <https://manned.org/alternatives>.

- Se dokumentationen för orginalkommandot:

`tldr update-alternatives`
