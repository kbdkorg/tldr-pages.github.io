# batcat

> Det här kommandot är ett alias för `bat`.
> Mer information: <https://github.com/sharkdp/bat>.

- Se dokumentationen för orginakommndot:

`tldr bat`
