# ubuntu-bug

> Det här kommandot är ett alias för `apport-bug`.
> Mer information: <https://manned.org/ubuntu-bug>.

- Se dokumentationen för orginalkommandot:

`tldr apport-bug`
