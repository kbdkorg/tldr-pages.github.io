# megadl

> Det här kommandot är ett alias för `megatools-dl`.
> Mer information: <https://megatools.megous.com/man/megatools-dl.html>.

- Se dokumentationen för orginalkommandot:

`tldr megatools-dl`
