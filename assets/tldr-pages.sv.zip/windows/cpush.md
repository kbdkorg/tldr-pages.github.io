# cpush

> Det här kommandot är ett alias för `choco-push`.
> Mer information: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Se dokumentationen för orginalkommandot:

`tldr choco-push`
