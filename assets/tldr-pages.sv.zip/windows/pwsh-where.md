# pwsh where

> Det här kommandot är ett alias för `Where-Object`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Se dokumentationen för orginalkommandot:

`tldr Where-Object`
