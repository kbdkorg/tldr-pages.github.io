# sls

> Det här kommandot är ett alias för `Select-String`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Se dokumentationen för orginalkommandot:

`tldr select-string`
