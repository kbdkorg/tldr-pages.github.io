# iwr

> Det här kommandot är ett alias för `invoke-webrequest`.
> Mer information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Se dokumentationen för orginalkommandot:

`tldr invoke-webrequest`
