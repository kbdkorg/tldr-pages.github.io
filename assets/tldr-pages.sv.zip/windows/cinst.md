# cinst

> Det här kommandot är ett alias för `choco install`.
> Mer information: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Se dokumentationen för orginalkommandot:

`tldr choco install`
