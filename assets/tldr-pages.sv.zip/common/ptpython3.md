# ptpython3

> Det här kommandot är ett alias för `ptpython`.

- Se dokumentationen för orginalkommandot:

`tldr ptpython`
