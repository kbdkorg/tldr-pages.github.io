# go bug

> Rapportera en bugg.
> Mer information: <https://golang.org/cmd/go/#hdr-Start_a_bug_report>.

- Öppna en webbsida för att starta en felrapport:

`go bug`
