# unxz

> Det här kommandot är ett alias för `xz`.
> Mer information: <https://manned.org/unxz>.

- Se dokumentationen för orginalkommandot:

`tldr xz`
