# fossil-new

> Det här kommandot är ett alias för `fossil-init`.
> Mer information: <https://fossil-scm.org/home/help/new>.

- Se dokumentationen för orginalkommandot:

`tldr fossil-init`
