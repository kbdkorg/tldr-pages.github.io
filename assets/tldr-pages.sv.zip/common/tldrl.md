# tldrl

> Det här kommandot är ett alias för `tldr-lint`.
> Mer information: <https://github.com/tldr-pages/tldr-lint>.

- Se dokumentationen för orginalkommandot:

`tldr tldr-lint`
