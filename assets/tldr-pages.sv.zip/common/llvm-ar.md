# llvm-ar

> Det här kommandot är ett alias för `ar`.

- Se dokumentationen för orginalkommandot:

`tldr ar`
