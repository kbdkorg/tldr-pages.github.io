# zbarimg

> Skanna och avkoda streckkoder från bildfil(er).
> Mer information: <http://zbar.sourceforge.net>.

- Processa en bill:

`zbarimg {{bild_il}}`
