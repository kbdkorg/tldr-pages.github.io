# hx

> Det här kommandot är ett alias för `helix`.

- Se dokumentationen för orginalkommandot:

`tldr helix`
