# platformio

> Det här kommandot är ett alias för `pio`.
> Mer information: <https://docs.platformio.org/en/latest/core/userguide/>.

- Se dokumentationen för orginalkommandot:

`tldr pio`
