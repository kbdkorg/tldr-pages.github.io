# unclutter

> Döljer muspekaren.
> Mer information: <https://manned.org/unclutter.1x>.

- Dölj muspekarn efter 3 sekunder:

`unclutter -idle {{3}}`
