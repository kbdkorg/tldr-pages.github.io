# ntl

> Det här kommandot är ett alias för `netlify`.
> Mer information: <https://cli.netlify.com>.

- Se dokumentationen för orginalkommandot:

`tldr netlify`
