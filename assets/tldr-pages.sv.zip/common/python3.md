# python3

> Det här kommandot är ett alias för `python`.

- Se dokumentationen för orginalkommandot:

`tldr python`
