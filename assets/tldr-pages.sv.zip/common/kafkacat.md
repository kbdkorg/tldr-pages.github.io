# kafkacat

> Det här kommandot är ett alias för `kcat`.

- Se dokumentationen för orginalkommandot:

`tldr kcat`
