# mscore

> Det här kommandot är ett alias för `musescore`.
> Mer information: <https://musescore.org/handbook/command-line-options>.

- Se dokumentationen för orginalkommandot:

`tldr musescore`
