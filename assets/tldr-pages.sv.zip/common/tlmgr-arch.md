# tlmgr-arch

> Det här kommandot är ett alias för `tlmgr platform`.
> Mer information: <https://www.tug.org/texlive/tlmgr.html>.

- Se dokumentationen för orginalkommandot:

`tldr tlmgr platform`
