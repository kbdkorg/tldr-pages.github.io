# ripgrep

> Det här kommandot är ett alias för `rg`.

- Se dokumentationen för orginalkommandot:

`tldr rg`
