# exit

> Avsluta shell.
> Mer information: <https://manned.org/exit>.

- Avsluta shell med utgångskoden från det senast utförda kommandot:

`exit`

- Avsluta shell med den angivna utgångskoden:

`exit {{utgångskoden}}`
