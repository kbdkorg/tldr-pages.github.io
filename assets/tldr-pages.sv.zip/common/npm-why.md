# npm-why

> Identifierar varför ett npm-paket är installerat.
> Mer information: <https://github.com/amio/npm-why>.

- Visa varför ett npm-paket är installerat:

`npm-why {{paket_namn}}`
