# view

> En skrivskyddad version av `vim`.
> Detta är lika med `vim -R`.
> Mer information: <https://www.vim.org>.

- Öppna en fil:

`view {{fil}}`
