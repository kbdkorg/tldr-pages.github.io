# users

> Visa en lista över inloggade användare.
> Mer information: <https://www.gnu.org/software/coreutils/users>.

- Visa en lista över inloggade användare:

`users`

- Visa en lista över inloggade användare enligt en specifik fil:

`users {{/var/log/wmtp}}`
