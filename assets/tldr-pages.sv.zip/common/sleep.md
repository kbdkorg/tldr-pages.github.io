# sleep

> Fördröjning under bestämd tid.
> Mer information: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html>.

- Fördröj i sekunder:

`sleep {{sekunder}}`

- Fördröj i minuter:

`sleep {{minuter}}m`

- Fördröj i timmar:

`sleep {{timmar}}h`
