# runit

> 3-stage init system.
> More information: <http://smarden.org/runit/runit.8.html>.

- Start runit's 3-stage init scheme:

`runit`

- Shut down runit:

`kill --CONT {{runit_pid}}`
