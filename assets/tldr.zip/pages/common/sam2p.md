# sam2p

> Raster (bitmap) image converter with smart PDF and PostScript (EPS) output.
> More information: <http://pts.50.hu/sam2p/>.

- Concatenate all PDF files into one:

`sam2p *.pdf {{path/to/output.pdf}}`
