# zstdless

> Open a `zstd` compressed file for interactive reading, allowing scrolling and search.
> See also: `zstd`, `less`.
> More information: <https://manned.org/zstdless>.

- Open a `zstd` compressed file:

`zstdless {{path/to/file.zst}}`
