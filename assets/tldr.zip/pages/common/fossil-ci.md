# fossil ci

> This command is an alias of `fossil commit`.
> More information: <https://fossil-scm.org/home/help/commit>.

- View documentation for the original command:

`tldr fossil-commit`
