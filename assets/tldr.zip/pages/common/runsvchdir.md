# runsvchdir

> Change the directory `runsvdir` uses by default.
> More information: <https://manpages.ubuntu.com/manpages/latest/man8/runsvchdir.8.html>.

- Switch `runsvdir` directories:

`sudo runsvchdir {{path/to/directory}}`
