# cargo new

> Create a new Cargo package.
> Equivalent of `cargo init`, but specifiying a directory is required.
> More information: <https://doc.rust-lang.org/cargo/commands/cargo-new.html>.

- Create a new Rust project with a binary target:

`cargo new {{path/to/directory}}`
