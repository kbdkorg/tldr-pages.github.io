# pgmbentley

> Bentleyize a PGM image.
> More information: <https://netpbm.sourceforge.net/doc/pgmbentley.html>.

- Apply the Bentley Effect on a PGM image:

`pgmbentley {{path/to/input_file.pgm}} > {{path/to/output_file.pgm}}`
