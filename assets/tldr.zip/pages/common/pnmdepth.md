# pnmdepth

> This command is an alias of `pamdepth`.
> More information: <https://netpbm.sourceforge.net/doc/pnmdepth.html>.

- View documentation for the original command:

`tldr pamdepth`
