# pnmtopnm

> This command is an alias of `pamtopnm`.
> More information: <https://netpbm.sourceforge.net/doc/pnmtopnm.html>.

- View documentation for the original command:

`tldr pamtopnm`
