# shar

> Create a shell archive.
> More information: <https://manned.org/man/freebsd/shar>.

- Create a shell script that when executed extracts the given files from itself:

`shar {{path/to/file1 path/to/file2 ...}} > {{path/to/archive.sh}}`
