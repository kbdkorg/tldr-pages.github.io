# hcloud

> Show how to use the CLI for Hetzner Cloud.
> More information: <https://github.com/hetznercloud/cli>.

- Show available commands and flags:

`hcloud`

- Display help:

`hcloud -h`

- Show available commands and flags for `hcloud` contexts:

`hcloud context`
