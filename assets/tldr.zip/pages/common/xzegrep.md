# xzegrep

> This command is an alias of `xzgrep --extended-regexp`.
> See also: `egrep`.

- View documentation for the original command:

`tldr xzgrep`
