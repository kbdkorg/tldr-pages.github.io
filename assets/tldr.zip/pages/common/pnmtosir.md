# pnmtosir

> Convert a PNM file to a Solitaire Image Recorder file.
> More information: <https://netpbm.sourceforge.net/doc/pnmtosir.html>.

- Convert a PNM image to a SIR image:

`pnmtosir {{path/to/input.pnm}} > {{path/to/output.sir}}`
