# alternatives

> This command is an alias of `update-alternatives`.
> More information: <https://manned.org/alternatives>.

- View documentation for the original command:

`tldr update-alternatives`
