# qm move disk

> This command is an alias of `qm disk move`.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- View documentation for the original command:

`tldr qm disk move`
