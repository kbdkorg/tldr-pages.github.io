# po4a

> Update both PO files and translated documents.
> More information: <https://po4a.org/man/man1/po4a.1.php>.

- Update PO files and documents according to the specified config file:

`po4a {{path/to/config_file}}`
