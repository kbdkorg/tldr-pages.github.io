# qm import disk

> This command is an alias of `qm disk import`.

- View documentation for the original command:

`tldr qm disk import`
