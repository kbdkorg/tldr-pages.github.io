# shntool split

> This command is an alias of `shnsplit`.

- View documentation for the original command:

`tldr shnsplit`
