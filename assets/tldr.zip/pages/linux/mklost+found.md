# mklost+found

> Create a lost+found directory.
> More information: <https://manned.org/mklost+found>.

- Create a `lost+found` directory in the current directory:

`mklost+found`
