# mate-calc

> Calculate mathematic expressions in MATE desktop environment.
> More information: <https://manned.org/mate-calc>.

- Start the calculator:

`mate-calc`

- Calculate a specific mathematic expression:

`mate-calc --solve {{2 + 5}}`
