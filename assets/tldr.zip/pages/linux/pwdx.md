# pwdx

> Print working directory of a process.
> More information: <https://manned.org/pwdx>.

- Print current working directory of a process:

`pwdx {{process_id}}`
