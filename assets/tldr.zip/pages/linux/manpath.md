# manpath

> Determine the search path for manual pages.
> More information: <https://manned.org/manpath>.

- Display the search path used to find man pages:

`manpath`

- Show the entire global manpath:

`manpath --global`
