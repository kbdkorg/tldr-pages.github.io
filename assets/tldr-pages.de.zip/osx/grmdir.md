# grmdir

> Dieser Befehl ist ein Alias von `-p linux rmdir`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr -p linux rmdir`
