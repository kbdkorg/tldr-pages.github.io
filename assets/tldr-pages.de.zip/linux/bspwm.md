# bspwm

> Dieser Befehl ist ein Alias von `bspc`.
> Weitere Informationen: <https://github.com/baskerville/bspwm>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr bspc`
