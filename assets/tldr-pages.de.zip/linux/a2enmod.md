# a2enmod

> Aktiviert ein Apache-Modul auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manpages.debian.org/latest/apache2/a2enmod.8.en.html>.

- Aktiviere ein Modul:

`sudo a2enmod {{modul}}`

- Zeige keine Informationsnachrichten an:

`sudo a2enmod --quiet {{modul}}`
