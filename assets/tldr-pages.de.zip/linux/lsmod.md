# lsmod

> Zeigt den Status von Linux-Kernel-Modulen an.
> Siehe auch `modprobe`, welches Kernel-Module lädt.
> Weitere Informationen: <https://manned.org/lsmod>.

- Liste alle aktuell geladenen Kernel-Module auf:

`lsmod`
