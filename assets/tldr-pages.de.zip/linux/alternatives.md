# alternatives

> Dieser Befehl ist ein Alias von `update-alternatives`.
> Weitere Informationen: <https://manned.org/alternatives>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr update-alternatives`
