# cc

> Dieser Befehl ist ein Alias von `gcc`.
> Weitere Informationen: <https://gcc.gnu.org>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr gcc`
