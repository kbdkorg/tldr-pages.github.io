# wm

> Zeige Informationen über den Bildschirm eines Android-Geräts.
> Dieser Befehl kann nur mit `adb shell` verwendet werden.
> Weitere Informationen: <https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Gib die physische Größe des Bildschirms eines Geräts aus:

`wm {{size}}`

- Gib die physische Pixeldichte des Bildschirms eines Geräts aus:

`wm {{density}}`
