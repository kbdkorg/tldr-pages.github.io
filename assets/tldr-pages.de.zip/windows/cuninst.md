# cuninst

> Dieser Befehl ist ein Alias von `choco uninstall`.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/choco/commands/uninstall>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr choco uninstall`
