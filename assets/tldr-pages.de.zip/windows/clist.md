# clist

> Dieser Befehl ist ein Alias von `choco list`.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr choco list`
