# pwsh where

> Dieser Befehl ist ein Alias von `Where-Object`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/where-object>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr Where-Object`
