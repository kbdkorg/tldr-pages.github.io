# sls

> Dieser Befehl ist ein Alias von `Select-String`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr select-string`
