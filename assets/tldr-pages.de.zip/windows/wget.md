# wget

> Dieser Befehl ist ein Alias von `wget -p common`.
> Weitere Informationen: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/invoke-webrequest>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr wget -p common`
