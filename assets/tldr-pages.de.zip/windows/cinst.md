# cinst

> Dieser Befehl ist ein Alias von `choco install`.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr choco install`
