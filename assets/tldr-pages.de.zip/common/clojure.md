# clojure

> Dieser Befehl ist ein Alias von `clj`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr clj`
