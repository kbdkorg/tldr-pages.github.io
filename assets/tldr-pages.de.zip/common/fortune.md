# fortune

> Gib ein zufälliges Glückskeks-Zitat aus.
> Weitere Informationen: <https://manned.org/fortune>.

- Gib ein Zitat aus:

`fortune`

- Gib ein beleidigendes Zitat aus:

`fortune -o`

- Gib ein langes Zitat aus:

`fortune -l`

- Gib ein kurzes Zitat aus:

`fortune -s`

- Gib alle verfügbaren Zitat-Datenbank-Dateien aus:

`fortune -f`

- Gib ein Zitat von einer durch `fortune -f` aufgelisteten Datenbank-Dateien aus:

`fortune {{dateiname}}`
