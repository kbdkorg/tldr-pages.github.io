# ntl

> Dieser Befehl ist ein Alias von `netlify`.
> Weitere Informationen: <https://cli.netlify.com>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr netlify`
