# hx

> Dieser Befehl ist ein Alias von `helix`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr helix`
