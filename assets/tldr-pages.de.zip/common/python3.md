# python3

> Dieser Befehl ist ein Alias von `python`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr python`
