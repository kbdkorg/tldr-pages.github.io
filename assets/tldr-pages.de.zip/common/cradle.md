# cradle

> Das Cradle PHP Framework.
> Manche Unterbefehle wie `cradle install` sind separat dokumentiert.
> Weitere Informationen: <https://cradlephp.github.io>.

- Stelle eine Verbindung zu einem Server her:

`cradle connect {{server}}`

- Zeige die Hilfe-Seite an:

`cradle help`

- Zeige die Hilfe-Seite für einen bestimmten Befehl:

`cradle {{befehl}} help`

- Führe einen Cradle-Befehl aus:

`cradle {{befehl}}`
