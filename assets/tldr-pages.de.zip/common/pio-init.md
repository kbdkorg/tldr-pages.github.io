# pio-init

> Dieser Befehl ist ein Alias von `pio project`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr pio project`
