# ptpython3

> Dieser Befehl ist ein Alias von `ptpython`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr ptpython`
