# ical

> Ein islamischer (Hijri) Kalender und Konverter für das Terminal.
> Weitere Informationen: <https://manned.org/ical>.

- Zeige den Kalender von diesem Monat an:

`ical`

- Konvertiere ein gregorianisches Datum zu einem islamischen Datum:

`ical --gregorian {{yyyymmdd}}`

- Konvertiere ein islamisches Datum zu einem gregorianischen Datum:

`ical --hijri {{yyyymmdd}}`
