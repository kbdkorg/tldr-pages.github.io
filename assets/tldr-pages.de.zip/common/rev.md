# rev

> Kehre die Reihenfolge von Text um.
> Weitere Informationen: <https://manned.org/rev>.

- Kehre die Reihenfolge des Textes "Hallo" um:

`echo "Hallo" | rev`

- Kehre die Reihenfolge einer Datei um:

`rev {{pfad/zu/datei}}`
