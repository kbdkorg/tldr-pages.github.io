# cron

> Dieser Befehl ist ein Alias von `crontab`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr crontab`
